package com.qa.pages;


import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.qa.base.TestBase;

public class SearchAndBookFlightPage extends TestBase{
	JavascriptExecutor js;
	
	@FindBy(xpath = "(//*[@class='radio__circle bs-border bc-neutral-500 bw-1 ba'])[2]")
	WebElement roundTripRadioButton;
	@FindBy(xpath="(//*[@type='text'])[1]")
	WebElement fromInput;
	@FindBy(xpath="//*[text()='Mumbai, IN - Chatrapati Shivaji Airport (BOM)']")
	WebElement fromAutoSuggestion;
	@FindBy(xpath="//*[text()='New Delhi, IN - Indira Gandhi Airport (DEL)']")
	WebElement toAutoSuggestion;
	@FindBy(xpath="(//*[@type='text'])[2]")
	WebElement toInput;
	@FindBy(xpath="(//*[@class='fs-2 c-inherit flex flex-nowrap'])[4]")
	WebElement departDate;
	@FindBy(xpath="(//*[@class='fs-2 c-inherit flex flex-nowrap'])[5]")
	WebElement returnDate;
	@FindBy(xpath="(//*[@class='bc-neutral-100 bg-transparent'])[1]")
	WebElement adultdropdown;
	@FindBy(xpath="(//*[@class='bc-neutral-100 bg-transparent'])[2]")
	WebElement childrenDropDown;
	@FindBy(xpath="//button[text()='Search flights']")
	WebElement searchFlights;
	@FindBy(xpath="//*[text()='This route is now open']")
	WebElement successMessage;
	@FindBy(xpath="//button[text()='Book']")
	WebElement bookButton;
	@FindBy(xpath="//*[text()='Add']")
	WebElement baggageProtection;
	@FindBy(xpath="(//*[text()='Continue'])[1]")
	WebElement continueButton;
	@FindBy(xpath="(//*[@class='c-secondary-600'])[1]")
	WebElement standardRadioButton;
	@FindBy(xpath="//*[@class='checkbox__mark bs-border bc-neutral-500 bw-1 ba bc-neutral-200 mx-2']")
	WebElement termsAndCondition;
	@FindBy(xpath="//button[text()='Select seats']")
	WebElement selectSeats;
	@FindBy(xpath="//button[text()='Done']")
	WebElement doneButton;
	@FindBy(xpath="//button[text()='View menu']")
	WebElement viewMenuButton;
	@FindBy(xpath="//*[text()='Save and Exit']")
	WebElement saveAndExitLink;
	@FindBy(xpath="(//button[text()='Continue'])[2]")
	WebElement secondContinueButton;
	@FindBy(xpath="//*[@data-testid='mobileNumber']")
	WebElement mobileNumberInput;
	@FindBy(xpath="//*[@data-testid='email']")
	WebElement emailInput;
	@FindBy(xpath="(//button[text()='Continue'])[3]")
	WebElement thirdContinueButton;
	@FindBy(xpath="(//*[@data-testid='firstName'])[1]")
	WebElement first_firstNameInput;
	@FindBy(xpath="(//*[@data-testid='lastName'])[1]")
	WebElement first_lastNameInput;
	@FindBy(xpath="//*[text()='Male']")
	WebElement first_GenderDropDown;
	@FindBy(xpath="(//*[@data-testid='firstName'])[2]")
	WebElement second_firstNameInput;
	@FindBy(xpath="(//*[@data-testid='lastName'])[2]")
	WebElement second_lastNameInput;
	@FindBy(xpath="(//*[text()='Male'])[2]")
	WebElement second_GenderDropDown;
	@FindBy(xpath="(//*[@data-testid='firstName'])[3]")
	WebElement third_firstNameInput;
	@FindBy(xpath="(//*[@data-testid='lastName'])[3]")
	WebElement third_lastNameInput;
	@FindBy(xpath="(//*[text()='Male'])[3]")
	WebElement third_GenderDropDown;
	@FindBy(xpath="//*[@placeholder='DD / MM / YYYY']")
	WebElement DobInput;
	@FindBy(xpath="//button[text()='Continue to payment']")
	WebElement continueToPaymentButton;
	@FindBy(xpath="//*[text()='Pay to complete your booking']")
	WebElement header;
	
	
	public SearchAndBookFlightPage(){
		PageFactory.initElements(driver, this);
	}
	public void clickOnRoundTripRadioButton() {
		roundTripRadioButton.click();
	}
	public void enterFromAndToLocations(String fromValue, String toValue) throws InterruptedException {
		
		fromInput.sendKeys(fromValue);
		fromAutoSuggestion.click();
		toInput.sendKeys(toValue);
		toAutoSuggestion.click();
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(2000);
	}
	public void enterTravelDates() throws InterruptedException {
		//driver.findElement(By.xpath("(//*[@class='fs-2 c-inherit flex flex-nowrap'])[4]")).click();
		departDate.click();
	    GregorianCalendar date = new GregorianCalendar();
	    int day = date.get(Calendar.DAY_OF_MONTH)+2;
	    WebElement form= driver.findElement(By.xpath("(//*[@role='gridcell'])["+Integer.toString(day)+"]"));
	    Actions action=new Actions(driver);
		action.doubleClick(form).perform();
	    Thread.sleep(3000);
	    
	    //driver.findElement(By.xpath("(//*[@class='fs-2 c-inherit flex flex-nowrap'])[5]")).click();
	    returnDate.click();
	    WebElement to=driver.findElement(By.xpath("(//*[@role='gridcell'])["+Integer.toString(day+2)+"]"));
	    action.doubleClick(to).perform();
	}
	
	public void selectFromDropDown(String adult, String children) {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)", "");
		Select selectAdult =new Select(adultdropdown);
		selectAdult.selectByVisibleText(adult);
		Select selectChildren =new Select(childrenDropDown);
		selectChildren.selectByVisibleText(children);
	}
	public void clickOnSearchFlight() {
		searchFlights.click();
	}
	
	public String validateFlightSearch() {
		return successMessage.getText();
	}
	public void clickOnBook() throws InterruptedException {
		bookButton.click();
		String parentWindow=driver.getWindowHandle();
		Set<String> allWindow=driver.getWindowHandles();
		for(String id: allWindow) {
			driver.switchTo().window(id);
		}
		Thread.sleep(6000L);
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		Thread.sleep(4000);
	}
	
	public void clickOnFirstContinue() throws InterruptedException {
		standardRadioButton.click();
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		Thread.sleep(2000L);
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,700)", "");
		Thread.sleep(2000L);
		continueButton.click();
		Thread.sleep(2000L);
	}
	
	public void SelectSeats() throws InterruptedException {
		selectSeats.click();
		List<WebElement> list=driver.findElements(By.xpath("//div[contains(@class,'c-pointer') and contains(@class,'br-4 w-100p h-100p c-pointer')]"));
		list.get(1).click();
		list.get(2).click();
		list.get(3).click();
		Thread.sleep(2000L);
		doneButton.click();
		Thread.sleep(2000L);
	}
	public void SelectMenu() throws InterruptedException {
		viewMenuButton.click();
		List<WebElement> list1=driver.findElements(By.xpath("//*[@d='M12 8v8M8 12h8']"));
		list1.get(0).click();
		list1.get(1).click();
		list1.get(2).click();
		Thread.sleep(2000L);
		doneButton.click();
		Thread.sleep(2000L);
		saveAndExitLink.click();
		Thread.sleep(2000L);
	}
	public void clickOnSecondContinue() throws InterruptedException {
		secondContinueButton.click();
		Thread.sleep(2000L);
	}
	public void addContactDetails() throws InterruptedException {
		mobileNumberInput.sendKeys("8844551122");
		Thread.sleep(2000L);
		emailInput.sendKeys("test3@test3.com");
		Thread.sleep(2000L);
		thirdContinueButton.click();
		Thread.sleep(2000L);
	}
	public void addTravellerDetails() throws InterruptedException {
		first_firstNameInput.sendKeys("Rahul");
		first_lastNameInput.sendKeys("kumar");
		Thread.sleep(2000L);
		List<WebElement> list2=driver.findElements(By.xpath("//*[@class='fs-inherit c-neutral-300 flex-nowrap']"));
		list2.get(0).click();
		Thread.sleep(1000L);
		first_GenderDropDown.click();
		Thread.sleep(2000L);
		second_firstNameInput.sendKeys("Ajay");
		second_lastNameInput.sendKeys("Verma");
		Thread.sleep(3000L);
		list2.get(1).click();
		Thread.sleep(3000L);
		second_GenderDropDown.click();
		Thread.sleep(2000L);
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(2000L);
		third_firstNameInput.sendKeys("Ramesh");
		third_lastNameInput.sendKeys("Sharma");
		Thread.sleep(3000L);
		list2.get(2).click();
		Thread.sleep(3000L);
		third_GenderDropDown.click();
		Thread.sleep(2000L);
		DobInput.sendKeys("05 / 06 / 2017");
		Thread.sleep(2000L);
	}
	public void clickOnContinueToPayment() throws InterruptedException {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		continueToPaymentButton.click();
		Thread.sleep(7000L);
	}
	public String validateHeaderOfNextPage() {
		return header.getText();
	}
}













