package com.qa.testcases;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.SearchAndBookFlightPage;
import com.qa.util.TestUtil;

public class SearchAndBookFlightTest extends TestBase{
	
	SearchAndBookFlightPage search;
	String sheetName="FlightSearch";
	
	public SearchAndBookFlightTest(){
		super();  // Calling constructor of parent class i.e. Test Base
	}
	@BeforeMethod
	public void setUp() throws InterruptedException{
		initialization();
		search = new SearchAndBookFlightPage();	
	}
	@Test(dataProvider="FlightSearch") 
	public void bookingFlightTest(String from, String To) throws InterruptedException {
	
		search.clickOnRoundTripRadioButton();
		search.enterFromAndToLocations(from, To);
		search.enterTravelDates();
		search.selectFromDropDown("2", "1");
		search.clickOnSearchFlight();
		String message=search.validateFlightSearch();
		Assert.assertEquals(message, "This route is now open");
		search.clickOnBook();
		search.clickOnFirstContinue();
		search.SelectSeats();
		search.SelectMenu();
		search.clickOnSecondContinue();
		search.addContactDetails();
		search.addTravellerDetails();
		search.clickOnContinueToPayment();
		String value=search.validateHeaderOfNextPage();
		Assert.assertEquals(value, "Pay to complete your booking");
	}
	
	@DataProvider(name = "FlightSearch")
	public Object[][] getTestData() throws InvalidFormatException {
		Object data[][]=TestUtil.getTestData(sheetName);
		return data;
	}
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
}